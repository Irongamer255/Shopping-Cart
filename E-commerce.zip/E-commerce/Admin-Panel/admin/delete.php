s<?php
    $id = $_GET["id"];

    $link = mysqli_connect("localhost", "root", "", "shop");
    $q = "DELETE from `user` where `id` = $id";

    $res = mysqli_query($link, $q);

    if($res){
        echo "User at id $id deleted!";
        header("location: index.php");
        die;
    }
    else{
        echo 'error';
    }

?>