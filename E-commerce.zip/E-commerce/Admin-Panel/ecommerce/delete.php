s<?php
    $id = $_GET["id"];

    $link = mysqli_connect("localhost", "root", "", "shop");
    $q = "DELETE from `order` where `id` = $id";

    $res = mysqli_query($link, $q);

    if($res){
        echo "Order at id $id deleted!";
        header("location: index.php");
        die;
    }
    else{
        echo 'error';
    }

?>