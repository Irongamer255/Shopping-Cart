<?php
    $first_name = @$_POST["first-name"];
    $last_name = @$_POST["last-name"];
    $email = @$_POST["email"];
    $pswd = @$_POST["password"];
    $confirm_pswd = @$_POST["password-confirm"];

    $link = mysqli_connect("localhost", "root", "", "php1");

    if($link){
        echo '<script>console.log("connected ✔")</script>';
        $q = "INSERT into `user` values (null, '$first_name', '$last_name', '$email', '$pswd', 1)";
        
        $res = mysqli_query($link, $q);

        if($res){
            echo 'data inserted!';
            header('location: index.php');
        }
        else{
            echo 'data not inserted';
        }
    }
    else{
        echo '<script>console.log("Error in connnection ❌")</script>';
    }


    
?>